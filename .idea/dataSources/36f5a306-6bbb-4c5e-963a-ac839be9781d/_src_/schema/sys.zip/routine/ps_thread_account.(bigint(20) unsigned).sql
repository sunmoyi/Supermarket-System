CREATE FUNCTION ps_thread_account(in_thread_id BIGINT)
  RETURNS TEXT
  BEGIN RETURN (SELECT IF( type = 'FOREGROUND', CONCAT(processlist_user, '@', processlist_host), type ) AS account FROM `performance_schema`.`threads` WHERE thread_id = in_thread_id); END;
